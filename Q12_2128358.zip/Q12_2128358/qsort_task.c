/* File:     qsort_task.c
 *
 * Purpose:  sort an array of elements using quicksort
 *
 * Compile:  gcc -g -Wall -fopenmp -o qsort_task qsort_task.c
 * Run:      ./qsort_task <number of elements> <cut_off_limit>
 *
 */

#include <stdlib.h>
#include <stdio.h>
//#include <math.h>
//#include <time.h>
//#include <sys/time.h>
//#include <unistd.h>
#include <omp.h>


void swap(float *data, int i, int j) {
	float t;
	t = data[i];
	data[i] = data[j];
	data[j] = t;
}
int partition(int p, int r, float *data) {
	float x=data[r];
	int i = p-1, j;
	for(j=p; j<r; j++) {
		if(data[j] <= x){
			i++;
			swap(data, i, j);
		}
	}
	swap(data, i+1, r);
	return i+1;
}

void seq_qsort(int p, int r, float *data){
	if(p < r){
		int q=partition(p, r, data);
		seq_qsort(p, q-1, data);
		seq_qsort(q+1, r, data);
	}
}

/*Parallel quicksort*/
void par_qsort(int p, int r, float *data, int low_limit){

	if(p < r){
		#pragma omp task
		{
		int q=partition(p, r, data);
		par_qsort(p, q-1, data,low_limit);
		par_qsort(q+1, r, data,low_limit);
		}
		}
}

void validate_sort(int n, float *data){
	int i;
	for(i=0;i<n-1;i++){
		if(data[i] > data[i+1]){
			printf("Validata failed. \n");
		}
	}
	printf("Validate passed.\n");
}

int main(int argc, char *argv[]){
	int i, n, low_limit;
	float *data;
    double start, s_time=0, p_time=0;
	if(argc != 3){
		printf("a.out num_elems low_limit\n");
		return 1;
	}
	n=atoi(argv[1]);
	low_limit=atoi(argv[2]);
	/*generate the array*/
    srand(2022);
	data=(float*)malloc(sizeof(float)*n);
	for(i=0; i<n; i++){
		data[i]=1.1*rand()*5000/RAND_MAX;
	}

    /*Serial quicksort*/
	printf("\nSorting %d numbers in serial...\n\n", n);
	start=omp_get_wtime();
	seq_qsort(0,n-1,&data[0]);
	s_time=omp_get_wtime() - start;
    
    validate_sort(n, &data[0]);

	for(i=0; i<n; i++){
		data[i]=1.1*rand()*5000/RAND_MAX;
	}
    
    /*Complete the parallel quicksort*/
    printf("\nSorting %d numbers in parallel...\n\n", n);
	start=omp_get_wtime();
	par_qsort(0,n-1,&data[0],low_limit);
	p_time=omp_get_wtime() - start;
	
    
    /*Uncomment to validate parallel sort*/
	validate_sort(n, &data[0]);

	printf("Sequential time: %lf s\n", s_time);
    /*Uncomment the following two lines to print out the time and speedup*/
	printf("Parallel time: %lf s\n", p_time);
	printf("That is a speedup: %f s\n", s_time/p_time);
	free(data);
	return 0;
}
